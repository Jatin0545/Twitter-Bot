Keys = dict(
	consumer_key =          'VpVpmtlSZ5RxLxnr6fG94QbB5',
	consumer_secret =       '6QUGI9OjML2AkwHVL6U01duodeS2OLAKJkR77pOQQSnVEr8z3t',
	access_token =          'VpVpmtlSZ5RxLxnr6fG94QbB5',
	access_token_secret =   '6QUGI9OjML2AkwHVL6U01duodeS2OLAKJkR77pOQQSnVEr8z3t',
)