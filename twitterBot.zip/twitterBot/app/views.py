from django.shortcuts import render
from django.http import HttpResponse

import os
import tweepy
# consumer_key = os.environ["API_KEY"]
# consumer_secret = os.environ["API_KEY_SECRET"]
# access_token = os.environ["ACCESS_TOKEN"]
# access_token_secret = os.environ["ACCESS_TOKEN_SECRET"]
# from keys import Keys

#Enter your API keys of twitter from developer.twitter.com
Keys = dict(
	consumer_key =          '',
	consumer_secret =       '',
	access_token =          '',
	access_token_secret =   '',
    bearer_token = '';
)

CONSUMER_KEY = Keys['consumer_key']
CONSUMER_SECRET = Keys['consumer_secret']
ACCESS_TOKEN = Keys['access_token']
ACCESS_TOKEN_SECRET = Keys['access_token_secret']
BEARER_TOKEN = Keys['bearer_token']
# auth = tweepy.OAuth1UserHandler(
#   CONSUMER_KEY, 
#   CONSUMER_SECRET, 
#   ACCESS_TOKEN, 
#   ACCESS_TOKEN
# )
# api = twitter.Api(consumer_key=CONSUMER_KEY,
#                   consumer_secret=CONSUMER_SECRET,
#                   access_token_key=ACCESS_TOKEN,
#                   access_token_secret=ACCESS_TOKEN_SECRET)
client = tweepy.Client(bearer_token=BEARER_TOKEN,
    consumer_key = CONSUMER_KEY, consumer_secret=CONSUMER_SECRET,access_token=ACCESS_TOKEN, access_token_secret=ACCESS_TOKEN_SECRET)
# auth = tweepy.OAuthHandler(CONSUMER_KEY, CONSUMER_SECRET)
# auth.set_access_token(ACCESS_TOKEN, ACCESS_TOKEN_SECRET)
# auth.set_access_token(ACCESS_TOKEN, ACCESS_TOKEN_SECRET)
# client1 = tweepy.API(auth)
# stream = tweepy.Stream(auth, tweepy.StreamListener)

# api = tweepy.API(auth)
# Create your views here.
def index(request):
    return render(request,'index.html')

def get_data(request):
    name = HttpResponse(request.POST.get('SearchQuery'))
    reply = str(request.POST.get('MessageToSend'))
    no_of_top_tweets = request.POST.get('TopTweets')
  #  print(no_of_top_tweets)
    tweets = client.search_recent_tweets(query=name,max_results=50)
    # data = tweets.data.text
    # print(tweets)
    arr = []
    for i in range(int(no_of_top_tweets)):
        in_reply_to_status_id = str(tweets.data[i].id)
        # status = "Hello"
        a=client.create_tweet(text=reply,in_reply_to_tweet_id=in_reply_to_status_id)
        string = tweets.data[i].text    
        arr.append(string)

    # print(r)
    context={
        "Tweets": arr,
        "no_of_tweets":no_of_top_tweets
    }
   # return HttpResponse(tweets.data[0].text) 
    return render(request,"tweet_page.html",context)